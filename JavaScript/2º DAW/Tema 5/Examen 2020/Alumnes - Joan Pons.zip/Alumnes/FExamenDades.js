// Estacions
var estacions = [{"provincia" : "Alacant",
                 "estacio" :  [
                    "Ondara",
                    "Benidorm",
                    "Alacant",
                    "Alcoi",
                    "Orihuela"
                 ]},
                 {"provincia" : "Valencia",
                  "estacio" : [
                      "Gandia",
                      "Alzira",
                      "Xàtiva",
                      "València",
                      "Requena"
                  ]},
                  {"provincia" : "Castello",
                  "estacio" : [
                      "Vinaròs",
                      "Castello",
                      "Vila-real",
                      ]}
                ];


