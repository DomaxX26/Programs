window.onload = main;

function main(){
    document.getElementById("guardar").addEventListener("click", nuevoProducto);
}