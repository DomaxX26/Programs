window.onload = main;

function main(){
    tenda();
}
