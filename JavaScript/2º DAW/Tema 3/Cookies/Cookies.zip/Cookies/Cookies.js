window.onload = main;

function main() {
	document.getElementById("enviar").addEventListener("click", cambiar_color('id'));
	document.getElementById("borrar").addEventListener("click", borrarCookies);
}




function cambiar_color(id) {
	var elemento = document.getElementById(id);
	elemento.style.display = "none";

	var miColor = document.getElementById("titulo");

	if (document.getElementById("blau").checked) {
		miColor.style.color = "blue";
		document.cookie = "color=blau";
	} else if (document.getElementById("roig").checked) {
		miColor.style.color = "red";
		document.cookie = "color=roig";
	} else {
		miColor.style.color = "green";
		document.cookie = "color=verd";
	}

	console.log(miColor.value);
}


function borrarCookies() {
	document.cookie = "color =; max-age=0;";
	alert("Cookies eliminadas correctamente");
}