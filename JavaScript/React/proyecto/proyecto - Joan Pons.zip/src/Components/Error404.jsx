import React from 'react'

function Error404 (){
    return (
        <div>
            <img src="https://cu.epm.com.co/portals/clientes_y_usuarios/Images/error-404.png"/>
        </div>
    )
}

export default Error404;
