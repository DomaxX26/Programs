import React from 'react';


export const Footer = () => {
    return (
        <div>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <p>&copy; 2022 Copyright - Tenda Ciclista - <span className="fw-bold">Exercici Final React</span></p>
                    </div>
                </div>
            </div>
        </div>
    )
}



export default Footer;

