import React from 'react'
import PropTypes from 'prop-types'
import { Container, Row, Col, FloatingLabel, Form, Button } from 'react-bootstrap';

const Main = props => {
    return (
        <div >
            <Container>
            <Row>
                <Col>
                    <h1 className="d-flex justify-content-start mb-4">Tasques</h1>
                </Col>  
            </Row>
            
                <Row>
                    <Col>
                        
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

Main.propTypes = {

}

export default Main;
